//
//  RecipeTypeVC.swift
//  RecipeApp
//
//  Created by Trung Le on 2/26/20.
//  Copyright © 2020 Trang Nguyen. All rights reserved.
//

import UIKit

class RecipeTypeVC: UIViewController {
    
    @IBOutlet weak var pkvRecipeType: UIPickerView!
    
    var currentRecipeType = [RecipeType] ()
    var selectedRow = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        let xmlParser = XMLDataParser()
        xmlParser.loadXMLFile { (data) in
             self.currentRecipeType = data
             self.pkvRecipeType.reloadAllComponents()
        }

    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if selectedRow < currentRecipeType.count {
            let item = currentRecipeType[selectedRow]
            if let vc = segue.destination as? RecipeListVC {
                vc.currentRecipeType = item
            }
            
        }
    }
}

extension RecipeTypeVC: UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return self.currentRecipeType.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if row < self.currentRecipeType.count {
            let recipeType = self.currentRecipeType[row]
            return recipeType.name
        }
        return ""
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectedRow = row
    }
}
