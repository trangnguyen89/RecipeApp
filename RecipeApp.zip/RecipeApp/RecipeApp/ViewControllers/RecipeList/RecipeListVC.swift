//
//  RecipeListVC.swift
//  RecipeApp
//
//  Created by Trung Le on 2/26/20.
//  Copyright © 2020 Trang Nguyen. All rights reserved.
//

import UIKit

class RecipeListVC: UIViewController {

    var currentRecipeType : RecipeType?
    var selectedIndex : Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    // MARK: - Navigation
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let recipeType = currentRecipeType {
            if self.selectedIndex < recipeType.recipes.count {
                let recipe = recipeType.recipes[self.selectedIndex]
                if let vc = segue.destination as? NewRecipeVC {
                    vc.currentRecipeType = self.currentRecipeType
                    vc.currentRecipeList = recipe
                }
                
            }
        }
        
    }
    

}

extension RecipeListVC : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let recipeType = currentRecipeType {
            return recipeType.recipes.count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ID_RECIPE_LIST", for: indexPath)
        if let recipeType = currentRecipeType {
            if indexPath.row < recipeType.recipes.count {
                let recipe = recipeType.recipes[indexPath.row]
                cell.textLabel?.text = recipe.name
            }
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.selectedIndex = indexPath.row
    }
    
    
}
