//
//  NewRecipeVC.swift
//  RecipeApp
//
//  Created by Trung Le on 2/26/20.
//  Copyright © 2020 Trang Nguyen. All rights reserved.
//

import UIKit

class NewRecipeVC: UIViewController {
    
    @IBOutlet weak var scvNewRecipe: UIScrollView!
    @IBOutlet weak var imvRecipe: UIImageView!
    @IBOutlet weak var txtIngridient: UITextView!
    @IBOutlet weak var txtSteps: UITextView!
    @IBOutlet weak var btnNewRecipe: UIButton!
    @IBOutlet weak var vwNewRecipe: UIView!
    @IBOutlet weak var vwEditRecipe: UIView!
    
    var selectView : UIView?
    
    let imagePicker = UIImagePickerController()
    var coreData = CoreData()
    var currentRecipeType : RecipeType?
    var currentRecipeList : Recipe?
    var haveRecipe : NewRecipe?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imagePicker.delegate = self
        self.vwNewRecipe.isHidden = false
        self.vwEditRecipe.isHidden = true
        
        if let recipeType = self.currentRecipeType, let recipeList = self.currentRecipeList {
            let recipes = coreData.fetchRecipe(withRecipeType: recipeType._id, withRecipeList: recipeList._id)
            if recipes.count > 0 {
                let recipe = recipes[0]
                self.haveRecipe = recipe
                let picture = self.convertBase64StringToImage(imageBase64String: recipe.image)
                self.imvRecipe.image = picture
                self.txtIngridient.text = recipe.ingredient
                self.txtSteps.text = recipe.steps
                self.vwNewRecipe.isHidden = true
                self.vwEditRecipe.isHidden = false
            }
        }
    }
    

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        registerKeyboardNotifications()
    }

    func registerKeyboardNotifications() {
        NotificationCenter.default.addObserver(self,
                                             selector: #selector(keyboardWillShow(notification:)),
                                             name: UIControl.keyboardWillShowNotification,
                                             object: nil)
        NotificationCenter.default.addObserver(self,
                                             selector: #selector(keyboardWillHide(notification:)),
                                             name: UIControl.keyboardWillHideNotification,
                                             object: nil)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        NotificationCenter.default.removeObserver(self)
    }

    @objc func keyboardWillShow(notification: NSNotification) {
       guard let keyboardFrame: CGRect = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue else { return }
       if self.scvNewRecipe != nil {
           self.scvNewRecipe.contentInset.bottom = keyboardFrame.height
           if let selectView = self.selectView, let superSelectView = selectView.superview {
               
               let realFrame = superSelectView.convert(selectView.frame, to: self.view)
               let endPointY = realFrame.origin.y + realFrame.size.height
               let moveDistance = endPointY - (self.view.frame.size.height - keyboardFrame.height)
               let fexibleDistance : CGFloat = 10
               if moveDistance > 0 {
                   self.scvNewRecipe.setContentOffset(CGPoint(x: self.scvNewRecipe.contentOffset.x,
                                                                y: self.scvNewRecipe.contentOffset.y + moveDistance + fexibleDistance),
                                                        animated: true)
               }
           }
       }
    }

    @objc func keyboardWillHide(notification: NSNotification) {
        scvNewRecipe.contentInset = .zero
        scvNewRecipe.scrollIndicatorInsets = .zero
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func onMakeNewRecipe(_ sender: Any) {
        var picture = ""
        if let image = self.imvRecipe.image {
            picture = self.convertImageToBase64String(img: image)
        }
        if let recipeType = self.currentRecipeType, let recipeList = self.currentRecipeList, let ingredinent = self.txtIngridient.text, let steps = self.txtSteps.text {
            let new = NewRecipe(_id: 1, _id_recipe_type: recipeType._id, _id_recipe_list: recipeList._id, image: picture, ingredient: ingredinent, steps: steps)
            coreData.addRecipe(new: new)
            self.navigationController?.popViewController(animated: true)
        }
        
    }
    
    @IBAction func onUpdateRecipe(_ sender: Any) {
        var picture = ""
        if let image = self.imvRecipe.image {
            picture = self.convertImageToBase64String(img: image)
        }
        if let recipeType = self.currentRecipeType, let recipeList = self.currentRecipeList, let ingredinent = self.txtIngridient.text, let steps = self.txtSteps.text {
            let new = NewRecipe(_id: 1, _id_recipe_type: recipeType._id, _id_recipe_list: recipeList._id, image: picture, ingredient: ingredinent, steps: steps)
            if self.haveRecipe != nil {
                coreData.updateRecipe(new: new)
            }
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    @IBAction func onDeleteRecipe(_ sender: Any) {
        if let recipeType = self.currentRecipeType, let recipeList = self.currentRecipeList {
            let new = NewRecipe(_id: 1, _id_recipe_type: recipeType._id, _id_recipe_list: recipeList._id, image: "", ingredient: "", steps: "")
            if self.haveRecipe != nil {
                coreData.deleteRecipe(new: new)
            }
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    
    @IBAction func onAddImage(_ sender: Any) {
        imagePicker.allowsEditing = false
        imagePicker.sourceType = .photoLibrary
            
        present(imagePicker, animated: true, completion: nil)
        
    }
    
    
    
    func convertImageToBase64String (img: UIImage) -> String {
        return img.jpegData(compressionQuality: 1)?.base64EncodedString() ?? ""
    }
    
    func convertBase64StringToImage (imageBase64String:String) -> UIImage {
        let imageData = Data.init(base64Encoded: imageBase64String, options: .init(rawValue: 0))
        let image = UIImage(data: imageData!)
        return image!
    }
    
    @IBAction func onTapOutside(_ sender: Any) {
        self.view.endEditing(true)
    }
    
}

extension NewRecipeVC : UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let pickedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            imvRecipe.contentMode = .scaleAspectFit
            imvRecipe.image = pickedImage
        }
        
        dismiss(animated: true, completion: nil)
    }
}


extension NewRecipeVC : UITextViewDelegate {
    func textViewShouldBeginEditing(_ textView: UITextView) -> Bool {
        self.selectView = textView
        
        return true
    }
}
