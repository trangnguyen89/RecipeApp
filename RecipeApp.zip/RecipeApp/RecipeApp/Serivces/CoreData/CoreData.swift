//
//  CoreData.swift
//  RecipeApp
//
//  Created by Trung Le on 2/27/20.
//  Copyright © 2020 Trang Nguyen. All rights reserved.
//

import UIKit
import CoreData

class CoreData: NSObject {
    // MARK: - Core Data stack

    lazy var persistentContainer: NSPersistentContainer = {
        /*
         The persistent container for the application. This implementation
         creates and returns a container, having loaded the store for the
         application to it. This property is optional since there are legitimate
         error conditions that could cause the creation of the store to fail.
        */
        let container = NSPersistentContainer(name: "RecipeApp")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                 
                /*
                 Typical reasons for an error here include:
                 * The parent directory does not exist, cannot be created, or disallows writing.
                 * The persistent store is not accessible, due to permissions or data protection when the device is locked.
                 * The device is out of space.
                 * The store could not be migrated to the current model version.
                 Check the error message to determine what the actual problem was.
                 */
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()
    
    
    var context: NSManagedObjectContext {
        return self.persistentContainer.viewContext
    }

    // MARK: - Core Data Saving support

    func saveContext () {
        let context = persistentContainer.viewContext
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
    
    func addRecipe (new : NewRecipe) {
        let recipe = RecipeTable(context: self.context)
        recipe.id_recipe = new._id
        recipe.id_recipe_type = new._id_recipe_type
        recipe.id_recipe_list = new._id_recipe_list
        recipe.picture = new.image
        recipe.ingredient = new.ingredient
        recipe.steps = new.steps
        
        self.context.insert(recipe)
        self.saveContext()
    }
    
    func updateRecipe (new : NewRecipe) {
        let request = NSFetchRequest<RecipeTable>(entityName: "RecipeTable")
        request.predicate = NSPredicate(format: "id_recipe_type == %d && id_recipe_list == %d", new._id_recipe_type, new._id_recipe_list)
        
        do {
            let recipes = try self.context.fetch(request)
            if recipes.count > 0 {
                let recipe = recipes[0]
                recipe.id_recipe = new._id
                recipe.id_recipe_type = new._id_recipe_type
                recipe.id_recipe_list = new._id_recipe_list
                recipe.picture = new.image
                recipe.ingredient = new.ingredient
                recipe.steps = new.steps
                self.saveContext()
            }
        }catch {}
    }
    
    func deleteRecipe (new : NewRecipe) {
        let request = NSFetchRequest<RecipeTable>(entityName: "RecipeTable")
               request.predicate = NSPredicate(format: "id_recipe_type == %d && id_recipe_list == %d", new._id_recipe_type, new._id_recipe_list)
               
       do {
           let recipes = try self.context.fetch(request)
           if recipes.count > 0 {
                let recipe = recipes[0]
                self.context.delete(recipe)
                self.saveContext()
            }
        }catch {}
    }
    
    func fetchRecipe(withRecipeType type: Int32, withRecipeList list : Int32) -> [NewRecipe] {
        let request = NSFetchRequest<RecipeTable>(entityName: "RecipeTable")
        request.predicate = NSPredicate(format: "id_recipe_type == %d && id_recipe_list == %d", type, list)
        var newRecipes = [NewRecipe]()
        do {
        let recipes = try self.context.fetch(request)
            for recipe in recipes {
                let item = NewRecipe(_id: recipe.id_recipe, _id_recipe_type: recipe.id_recipe_type, _id_recipe_list: recipe.id_recipe_list, image: recipe.picture ?? "", ingredient: recipe.ingredient ?? "", steps: recipe.steps ?? "")
                newRecipes.append(item)
            }

        }catch {}
        return newRecipes
    }
}

