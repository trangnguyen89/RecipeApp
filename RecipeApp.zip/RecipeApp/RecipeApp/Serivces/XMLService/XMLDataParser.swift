//
//  XMLDataParser.swift
//  RecipeApp
//
//  Created by Trung Le on 2/26/20.
//  Copyright © 2020 Trang Nguyen. All rights reserved.
//

import UIKit

class XMLDataParser: NSObject,XMLParserDelegate {
    private var completionParser : (([RecipeType]) -> Void)?
    
    func loadXMLFile (completion : (([RecipeType]) -> Void)?) {
        completionParser = completion
        if let path = Bundle.main.url(forResource: "RecipeTypes", withExtension: "xml") {
            if let parser = XMLParser(contentsOf: path) {
                parser.delegate = self
                parser.parse()
            }
        }
    }
    
    var currentParsingElement = ""
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]){
        currentParsingElement = elementName
    }
    
    var recipe_type_id : Int32 = 0
    var recipe_type_name = ""
    var recipe_id : Int32 = 0
    var recipe_name = ""
    var current_recipes = [Recipe]()
    var recipeTypes = [RecipeType]()
    
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        let foundedChar = string.trimmingCharacters(in:NSCharacterSet.whitespacesAndNewlines) as NSString
        if foundedChar.length > 0 {
            if currentParsingElement == "recipe_type_id" {
                recipe_type_id = foundedChar.intValue
            }
            else if currentParsingElement == "recipe_type_name" {
                recipe_type_name = foundedChar as String
            }else if (currentParsingElement == "recipe_id") {
                recipe_id = foundedChar.intValue
            }else if (currentParsingElement == "recipe_name"){
                recipe_name = foundedChar as String
            }
        }
    }
    
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        if elementName == "recipe_type" {
            let recipeType = RecipeType(_id: recipe_type_id, name: recipe_type_name, recipes: current_recipes)
            self.recipeTypes.append(recipeType)
            recipe_type_id = 0
            recipe_type_name = ""
            self.current_recipes.removeAll()
        }else if elementName == "recipe" {
            let recipe = Recipe(_id: recipe_id, name: recipe_name)
            self.current_recipes.append(recipe)
            recipe_id = 0
            recipe_name = ""
        }else if elementName == "recipe_types" {
            if let completion = completionParser {
                completion(recipeTypes)
            }
        }
    }
    
}
