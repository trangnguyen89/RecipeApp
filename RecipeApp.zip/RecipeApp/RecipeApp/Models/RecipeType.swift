//
//  RecipeType.swift
//  RecipeApp
//
//  Created by Trung Le on 2/26/20.
//  Copyright © 2020 Trang Nguyen. All rights reserved.
//

import UIKit

struct RecipeType  {
    var _id : Int32
    var name : String
    var recipes : [Recipe]
}
