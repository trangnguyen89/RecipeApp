//
//  NewRecipe.swift
//  RecipeApp
//
//  Created by Trung Le on 2/27/20.
//  Copyright © 2020 Trang Nguyen. All rights reserved.
//

import UIKit

struct NewRecipe {
    var _id : Int32
    var _id_recipe_type : Int32
    var _id_recipe_list : Int32
    var image : String
    var ingredient : String
    var steps : String
}


